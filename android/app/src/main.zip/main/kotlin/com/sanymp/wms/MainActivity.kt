package com.sanymp.wms

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
